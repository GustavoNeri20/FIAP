package br.com.fiap.funcional;

import java.util.ArrayList;
import java.util.List;

public class Funcionalidades {


	static List<String> lista = new ArrayList<String>();

	// A)Cadastrar
	public String cadastrar(String produto) {

		lista.add("Carteira");
		lista.add("Caderno");
		lista.add("Livro");
		lista.add("Estojo");
		lista.add("Caneta");
		lista.add("Toalha");
		lista.add("Teclado");
		lista.add(produto);

		return produto + " Cadastrado com Sucesso";

	}


	// b)Atualizar
	public String atualizar(int local, String produto) {
		lista.set(local, produto);
		return "Atualizado com Sucesso";

	}

	// c)Remover
	public String remover(int index) {
		lista.remove(index);

		return "Removido com Sucesso";
	}

	// d)Listar
	public List<String> listar() {
        
        for(String s:lista) {
        	
            return lista;
        }
		return null;
        


    }

}
