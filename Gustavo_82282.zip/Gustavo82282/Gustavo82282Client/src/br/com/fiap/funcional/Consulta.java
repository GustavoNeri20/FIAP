package br.com.fiap.funcional;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.axis2.AxisFault;

import br.com.fiap.funcional.FuncionalidadesStub.Atualizar;
import br.com.fiap.funcional.FuncionalidadesStub.AtualizarResponse;
import br.com.fiap.funcional.FuncionalidadesStub.Cadastrar;
import br.com.fiap.funcional.FuncionalidadesStub.CadastrarResponse;
import br.com.fiap.funcional.FuncionalidadesStub.Listar;
import br.com.fiap.funcional.FuncionalidadesStub.ListarResponse;
import br.com.fiap.funcional.FuncionalidadesStub.Remover;
import br.com.fiap.funcional.FuncionalidadesStub.RemoverResponse;

public class Consulta{

	static List<String> lista = new ArrayList<String>();
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int acao=0;
		
		try {
			while(acao==0) {
			System.out.println("Digite 1 para cadastrar, 2 atualizar, 3 remover, 4 listar");
			acao = sc.nextInt();
			FuncionalidadesStub ft = new FuncionalidadesStub();
			if(acao==1) {
				Cadastrar cadastrar = new Cadastrar();
				cadastrar.setProduto("Monitor");
				CadastrarResponse cr = ft.cadastrar(cadastrar);
				System.out.println(cadastrar.getProduto() + " cadastrado com sucesso!");
			}else if(acao==2) {
				Atualizar atualizar = new Atualizar();
				atualizar.setLocal(2);
				atualizar.setProduto("Livro");
				AtualizarResponse ar = ft.atualizar(atualizar);
				System.out.println("Atualizado com Sucesso");
			}else if(acao==3) {
				Remover remover = new Remover();
				remover.setIndex(3);
				RemoverResponse rr = ft.remover(remover);
				System.out.println("Removido com Sucesso");
			}else if(acao==4) {
				Listar listar = new Listar();
				ListarResponse lr = ft.listar(listar);
				System.out.println(lr);
			}
				System.out.println("Deseja fazer algo a mais? Digite 0");
				acao = sc.nextInt();
			
			}
		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
